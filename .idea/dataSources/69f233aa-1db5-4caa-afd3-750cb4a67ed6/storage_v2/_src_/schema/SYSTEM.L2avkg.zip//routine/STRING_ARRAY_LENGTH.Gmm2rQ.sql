create function string_array_length(arr in string_array) return number deterministic is begin if arr is null then return null; end if; return arr.count; end;
/

