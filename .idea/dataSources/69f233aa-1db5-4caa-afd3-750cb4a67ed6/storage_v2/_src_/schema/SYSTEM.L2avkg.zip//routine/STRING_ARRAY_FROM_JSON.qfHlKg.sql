create function string_array_from_json(arr in blob) return string_array deterministic is res string_array:=string_array(); begin if arr is null then return null; end if; select t.value bulk collect into res from json_table(arr,'$[*]' columns (value path '$')) t; return res; end;
/

