create function string_array_set(arr in string_array, idx in number, elem in varchar2) return string_array deterministic is res string_array:=string_array(); begin if arr is not null then for i in 1 .. arr.count loop res.extend; res(i) := arr(i); end loop; for i in arr.count+1 .. idx loop res.extend; end loop; else for i in 1 .. idx loop res.extend; end loop; end if; res(idx) := elem; return res; end;
/

