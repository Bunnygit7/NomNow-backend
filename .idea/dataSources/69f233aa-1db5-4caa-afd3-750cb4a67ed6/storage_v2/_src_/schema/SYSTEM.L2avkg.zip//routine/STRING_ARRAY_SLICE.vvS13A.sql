create function string_array_slice(arr in string_array, startIdx in number, endIdx in number) return string_array deterministic is res string_array:=string_array(); begin if arr is null or startIdx is null or endIdx is null then return null; end if; for i in startIdx .. least(arr.count,endIdx) loop res.extend; res(res.last) := arr(i); end loop; return res; end;
/

