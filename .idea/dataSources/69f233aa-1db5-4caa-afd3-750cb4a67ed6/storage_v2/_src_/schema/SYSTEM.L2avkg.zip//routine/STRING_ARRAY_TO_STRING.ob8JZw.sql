create function string_array_to_string(arr in string_array, sep in varchar2, nullVal in varchar2) return varchar2 deterministic is res varchar2(4000):=''; begin if arr is null or sep is null then return null; end if; for i in 1 .. arr.count loop if arr(i) is not null then if length(res)<>0 then res:=res||sep; end if; res:=res||arr(i); elsif nullVal is not null then if length(res)<>0 then res:=res||sep; end if; res:=res||nullVal; end if; end loop; return res; end;
/

