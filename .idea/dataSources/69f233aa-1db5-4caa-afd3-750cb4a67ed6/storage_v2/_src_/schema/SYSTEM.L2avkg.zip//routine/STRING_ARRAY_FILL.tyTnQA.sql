create function string_array_fill(elem in varchar2, elems number) return string_array deterministic is res string_array:=string_array(); begin if elems is null then return null; end if; if elems<0 then raise_application_error (-20000, 'number of elements must be greater than or equal to 0'); end if;for i in 1 .. elems loop res.extend; res(i) := elem; end loop; return res; end;
/

