create function string_array_remove_index(arr in string_array, idx in number) return string_array deterministic is res string_array:=string_array(); begin if arr is null or idx is null then return arr; end if; for i in 1 .. arr.count loop if i<>idx then res.extend; res(res.last) := arr(i); end if; end loop; return res; end;
/

