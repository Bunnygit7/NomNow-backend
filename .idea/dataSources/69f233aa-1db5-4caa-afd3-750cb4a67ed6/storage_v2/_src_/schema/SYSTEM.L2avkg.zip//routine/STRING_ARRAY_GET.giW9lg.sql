create function string_array_get(arr in string_array, idx in number) return varchar2 deterministic is begin if arr is null or idx is null or arr.count < idx then return null; end if; return arr(idx); end;
/

